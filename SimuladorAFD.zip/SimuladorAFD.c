/* Nomes: Lucas Rezende e Vitor Loredo */
#include <stdio.h>

int main(void){ /* Main */

	int i, j, k, l, m; /* Iteradores */
    FILE *arquivo; /* Arquivo */
    char simbolo[10]; /* S�mbolos */
    int numEstados; /* N�mero de estados */
    int numEstadosFinais; /* N�mero de estados finais */
    char estadosFinais[20]; /* Estados finais */
    int numTransicoes; /* N�mero de transi��es */
    int numPalavrasTestadas; /* N�mero de palavras a serem testadas */
    char palavra[100]; /* Palavras */
    char estado = '0'; /* Estado */
    int letraVerif = 0; /* Verifica se a letra j� foi lida */
    int cont = 0; /* Conta a quantidade de letras */
    int estadoVerif = 0; /* Armazena se o estado final j� foi verificado */
    char buffer; /* Armazena uma letra da palavra */


    arquivo = fopen("quintupla.txt", "r");

    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo!");
    } else{

        fscanf(arquivo, "%s\n", simbolo);
        fscanf(arquivo, "%i\n", &numEstados);
        fscanf(arquivo, "%i\n", &numEstadosFinais);

        for (i = 0; i<numEstadosFinais; i++)
            fscanf(arquivo, "%c\n", &estadosFinais[i]);

        fscanf(arquivo, "%i\n", &numTransicoes);

        char transicoes[numTransicoes][3];

        for (i = 0; i<numTransicoes; i++){
            for (j = 0; j<3; j++){
                fscanf(arquivo, "%s\n", &transicoes[i][j]);
            }
        }

        fscanf(arquivo, "%i\n", &numPalavrasTestadas);

        for (i = 0; i<numPalavrasTestadas; i++){
            printf("\n");
            printf("%i: ", i+1);
            for (l = 0; l<100; l++){
                buffer = fgetc(arquivo);
                if (buffer!='\n'){
                    printf("%c", buffer);
                    palavra[l] = buffer;
                    cont++;
                } else {
                    l =101;
                }
            }
            printf("\n");
            for (k = 0; k<cont; k++){
                for (j = 0; j<numTransicoes; j++){
                    if (letraVerif != 1){
                        if (estado == transicoes[j][0]){
                            if (palavra[k] == transicoes[j][1]){
                                estado = transicoes[j][2];
                                letraVerif = 1;
                            }
                        }
                    }
                }
                letraVerif = 0;
            }

            for (m = 0; m<numEstadosFinais; m++){
                if (estadoVerif==0){
                    if (estado == estadosFinais[m]){
                        estadoVerif = 1;
                    }
                }
            }

            if (estadoVerif == 1){
                printf(" OK");
                printf("\n");
            } else {
                printf(" not OK");
                printf("\n");
            }

            cont = 0;
            estado = '0';
            estadoVerif = 0;
        }

        fclose(arquivo);

        return 0; /* Fim */

    }
}
